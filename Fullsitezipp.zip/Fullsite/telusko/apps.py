from django.apps import AppConfig


class TeluskoConfig(AppConfig):
    name = 'telusko'
